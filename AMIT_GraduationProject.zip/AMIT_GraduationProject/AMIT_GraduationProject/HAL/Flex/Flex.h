

#ifndef FLEX_H_
#define FLEX_H_

#include "Flex_Cfg.h"
#include "DIO.h"
#include "STD_TYPES.h"

void    Flex_Init();
uint16t Flex_Read(uint8_t);

#endif /* FLEX_H_ */