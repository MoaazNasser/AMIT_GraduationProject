

#ifndef FLEX_CFG_H_
#define FLEX_CFG_H_

#define Flex0Port DIO_PORTA
#define Flex0Pin  Pin0

#define Flex1Port DIO_PORTA
#define Flex1Pin  Pin4

#define Flex2Port DIO_PORTA
#define Flex2Pin  Pin5

#define Flex3Port DIO_PORTA
#define Flex3Pin  Pin6

#define Flex4Port DIO_PORTA
#define Flex4Pin  Pin7

#endif /* FLEX_CFG_H_ */